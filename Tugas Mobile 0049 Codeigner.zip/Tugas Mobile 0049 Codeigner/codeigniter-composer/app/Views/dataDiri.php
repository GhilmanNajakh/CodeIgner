<?php
// Menyimpan data diri dalam variabel
$nama = "M.Ghilman Najakh";
$alamat = "Kedungwuni Kab.Pekalongan";
$tanggal_lahir = "25 Oktober 2005";
$email = "ghilman.najakh@gmail.com";
$no_telepon = "085823652670";
$hobi = array("Makan", "Bermain Game", "Bermain Basket");
$kuliah = "INSTITUT WIDYA PRATAMA";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Diri</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #a8c0ff, #3f6ad8); /* Gradasi Biru Kalem */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .container {
            width: 70%;
            max-width: 650px;
            background: linear-gradient(145deg, #d0e7ff, #a0c4ff); /* Gradasi Biru Kalem Lembut */
            padding: 30px;
            border-radius: 20px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1), -5px -5px 15px rgba(255, 255, 255, 0.8);
            text-align: center;
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #4b79a1;
            background: -webkit-linear-gradient(#4b79a1, #283e51);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .data-item {
            margin: 15px 0;
            font-size: 1.2rem;
            color: #555;
            padding: 12px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .data-item strong {
            font-weight: bold;
            color: #333;
        }

        .data-item span {
            display: block;
            margin-top: 5px;
            color: #666;
        }

        .hobi {
            font-style: italic;
            color: #4b79a1;
        }

        .kembali {
            display: inline-block;
            margin-top: 20px;
            background: linear-gradient(135deg, #ff7f50, #ff6347); /* Gradasi Oranye ke Merah */
            color: white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 15px rgba(161, 196, 253, 0.4);
        }

        .kembali:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(161, 196, 253, 0.5);
        }

        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            h1 {
                font-size: 2rem;
            }

            .data-item {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Data Diri</h1>

    <div class="data-item">
        <strong>Nama:</strong>
        <span><?php echo $nama; ?></span>
    </div>

    <div class="data-item">
        <strong>Alamat:</strong>
        <span><?php echo $alamat; ?></span>
    </div>

    <div class="data-item">
        <strong>Tanggal Lahir:</strong>
        <span><?php echo $tanggal_lahir; ?></span>
    </div>

    <div class="data-item">
        <strong>Email:</strong>
        <span><?php echo $email; ?></span>
    </div>

    <div class="data-item">
        <strong>No Telepon:</strong>
        <span><?php echo $no_telepon; ?></span>
    </div>

    <div class="data-item hobi">
        <strong>Hobi:</strong>
        <span><?php echo implode(", ", $hobi); ?></span>
    </div>

    <div class="data-item">
        <strong>Kuliah:</strong>
        <span><?php echo $kuliah; ?></span>
    </div>

    <a class="kembali" href="welcome_message">Kembali</a>
</div>

</body>
</html>
